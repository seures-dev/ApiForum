create function trg_decrem_post_count() returns trigger
    language plpgsql
as
$$
		BEGIN
		  UPDATE branches
		  SET message_count = message_count - 1
		  WHERE id = OLD.branch_id
				AND EXISTS (SELECT 1 FROM branches WHERE id = OLD.branch_id);
		  RETURN NULL;
		END;
		$$;

alter function trg_decrem_post_count() owner to seures;

