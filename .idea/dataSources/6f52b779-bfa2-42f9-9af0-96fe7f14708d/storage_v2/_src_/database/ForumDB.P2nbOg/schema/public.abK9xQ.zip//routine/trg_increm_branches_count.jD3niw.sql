create function trg_increm_branches_count() returns trigger
    language plpgsql
as
$$
		BEGIN
		  UPDATE threads
		  SET branch_count = branch_count + 1
		  WHERE thread_id = NEW.thread_id
				AND EXISTS (SELECT 1 FROM branches WHERE thread_id = NEW.thread_id);
		  RETURN NULL;
		END;
		$$;

alter function trg_increm_branches_count() owner to seures;

