create function trg_decrem_branch_count() returns trigger
    language plpgsql
as
$$
		BEGIN
		  UPDATE threads
		  SET branch_count = branch_count - 1
		  WHERE thread_id = OLD.thread_id
				AND EXISTS (SELECT 1 FROM branches WHERE id = OLD.thread_id);
		  RETURN NULL;
		END;
		$$;

alter function trg_decrem_branch_count() owner to seures;

