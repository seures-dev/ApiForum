create function trg_sibi() returns trigger
    language plpgsql
as
$$
			BEGIN
			  NEW.into_branch_id := (SELECT message_count FROM branches WHERE id = NEW.branch_id) + 1;
			  RETURN NEW;
			END;
			$$;

alter function trg_sibi() owner to seures;

